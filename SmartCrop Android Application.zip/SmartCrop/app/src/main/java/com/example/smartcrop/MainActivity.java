package com.example.smartcrop;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity<ProgessBar> extends AppCompatActivity {

    FirebaseAuth mAuth;

    private EditText Name;
    private EditText Password;
    private TextView Info,Signup;
    private Button Login;
    private int counter=5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth=FirebaseAuth.getInstance();

        Name=(EditText)findViewById(R.id.etName);
        Password=(EditText)findViewById(R.id.etPassword);
        Info=(TextView)findViewById(R.id.tvInfo);
        Signup=(TextView)findViewById(R.id.forsignup);
        Login=(Button)findViewById(R.id.btnLogin);

        Info.setText("No of attempts remaining: 5");
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(Name.getText().toString(),Password.getText().toString());
            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(MainActivity.this,ThirdActivity.class);
                startActivity(intent1);
            }
        });

    }
    private void validate(String email,String password){

        if(email.isEmpty()){
            Name.setError("Email is required");
            Name.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            Name.setError("Please Enter a valid email");
            Name.requestFocus();
            return;
        }
        if(password.length()<6){
            Password.setError("Minimum length should be 6");
            Password.requestFocus();
            return;
        }
        if(password.isEmpty()){
            Password.setError("Password is Required");
            Password.requestFocus();
            return;
        }




            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }else{

                        counter--;
                        Info.setText("No of attempts remaining: " + String.valueOf(counter));
                        if (counter == 0) {
                            Login.setEnabled(false);
                        }
                        Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
            });


    }
}
